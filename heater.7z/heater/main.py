#import main_wifi
#import ntptime
#ntptime.settime()
# import coin_back

import demo
# import coin_test
# import pulse_test
# import coin_pulse
