from max6675 import MAX6675
from machine import Pin, Timer, ADC
import machine
import time

# 家用迴焊爐實作 Reflow Oven DIY
# http://www.erichuang.com/2120525163205702352635352/reflow-oven-diy


so = Pin(12, Pin.IN)
sck = Pin(14, Pin.OUT)
cs = Pin(16, Pin.OUT)

heater = Pin(27, Pin.OUT)

start = Pin(26, Pin.IN)
start.value()


Buzzer = Pin(25, Pin.OUT)
Buzzer.value(1)

# https://randomnerdtutorials.com/esp32-esp8266-analog-readings-micropython/
setting = ADC(Pin(36))
setting.atten(ADC.ATTN_11DB)
setting.read()

settime = ADC(Pin(39))
settime.atten(ADC.ATTN_11DB)
settime.read()


max = MAX6675(sck, cs , so)

global config_start
config_start = False

global config_deg
config_deg = 0

global config_time
config_time = 0

global status_time
status_time = 0

global status_deg
status_deg = 0

global status_num
status_num = 0


# 輸出到顯示器出貨
def report_draw_OutPut():

	from st7920 import Screen
	from sysfont import sysfont

	global param
	global Json_log

	# for esp32s
	spi = machine.SPI(2, baudrate=100000, polarity=1, phase=1, sck=machine.Pin(18), mosi=machine.Pin(23))
	screen = Screen(spi=spi)

	screen.clear()    
	
	global status_deg
	global config_deg
	MESSAGE = "deg: {:0.1f} set: {:0.0f}".format(status_deg , config_deg)
	screen.text((1, 3), MESSAGE, sysfont , 1)
	
	global config_time
	global status_time
	MESSAGE = "time:{:04d} count:{:04d}".format(config_time , status_time)
	screen.text((1, 13), MESSAGE, sysfont , 1)

	global config_start
	if heater.value() == 0:
		MESSAGE = "Heater: On  ON: {:s}".format(str(config_start))
	else:
		MESSAGE = "Heater: Off On: {:s}".format(str(config_start))
	screen.text((1, 23), MESSAGE, sysfont , 1)
	
	MESSAGE = "Time val {:d}".format(int( settime.read() / 13 ))
	screen.text((1, 33), MESSAGE, sysfont , 1)
	
	
	screen.redraw()
	
# 0 - 4095 / 0--3xx	
	
def CheckPins(pin):
	global status_deg
	global config_deg
	global config_time
	global config_start
	global status_time
	
	global status_num
	status_num = status_num + 1
	
	if status_time > 0 :
		status_time = status_time - 1
		
	#config_time = int( settime.read() / 13 )
	#print(config_time)
	
	status_deg = max.read()
	print(status_deg)
	report_draw_OutPut()
	config_deg = setting.read() / 13
	
	
	if config_start == False:
		#status_num = 0
		heater.value(1)
	
	if status_time == 1:
		Buzzer.value(0)

	if status_time == 0:
		Buzzer.value(1)
				
	# 關閉加熱器 24 24
	if status_deg > (config_deg -1) or status_time == 0:
		heater.value(1)
		if status_time < 1:
			config_start = False

		
	# 打開加熱器 21  22
	if status_deg < (config_deg -2) and status_time > 0:
		heater.value(0)
		
	if start.value() == 1 and (status_num % 3 == 2):
		status_num = 0
		config_start = not config_start
		print(config_start)
		
		if config_start == True:
			config_time = int( settime.read() / 13 )
			status_time = config_time
		else:
			heater.value(1)
			status_time = 0



# 檢查鍵盤，是否有退幣測試事件
timer = Timer(-1)
timer.init(period=1000, mode=Timer.PERIODIC, callback=CheckPins)
	
